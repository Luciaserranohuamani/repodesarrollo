<!-- JOSEPH-->
<?php


class modelUsuario extends CI_Model
{

 function __construct()
 {
  parent::__construct();
 }

 public function guardar($parametros){
  $this->db->insert('usuario', $parametros);
  return $this->db->insert_id();
 }
 public function selPerfil()
  {
    $query = $this->db->query("select * from perfil");
    return $query->result();
  }

 public function listado(){
  $r = $this->db->query("
  SELECT * FROM usuario inner join perfil on usuario.perid = perfil.perid
");
  return $r->result();
 }

 public function editar($parametros){
  $e = $this->db->get_where('usuario', $parametros);
  return $e->result();
 }

 public function actualizar($parametros, $usuid){
  $this->db->where('usuid', $usuid);
  $this->db->update('usuario', $parametros);
  return 1;
 }

 public function eliminar($parametro){
   $this->db->delete('usuario', $parametro);
 }
}
