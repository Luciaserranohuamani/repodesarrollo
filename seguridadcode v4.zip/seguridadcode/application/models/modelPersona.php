<!-- JOSEPH-->
<?php

/**
*
*/
class modelPersona extends CI_Model
{

function __construct()
{
parent::__construct();
}

public function guardar($parametros){
$this->db->insert('productos', $parametros);
return $this->db->insert_id();
}

public function listado(){
$r = $this->db->get("productos");
return $r->result();
}

public function editar($parametros){
$e = $this->db->get_where('productos', $parametros);
return $e->result();
}

public function actualizar($parametros, $id){
$this->db->where('id', $id);
$this->db->update('productos', $parametros);
return 1;
}

public function eliminar($parametro){
 $this->db->delete('productos', $parametro);
}
}
