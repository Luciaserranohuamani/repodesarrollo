
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <title>CRUD DE USUARIO</title>
 <head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="<?php echo base_url('public/css/bootstrap.css')?>" rel="stylesheet">
    <!--<link rel="stylesheet" href="public/css/bootstrap.min.css">-->

    <script src="<?php echo base_url('public/js/jquery.min.js')?>"></script>
    <script src="<?php echo base_url('public/js/bootstrap.js')?>"></script>

    <script src="<?php echo base_url('public/js/jquery.dataTables.min.js')?>"></script>
    <script src="<?php echo base_url('public/js/jquery.dataTables.bootstrap.js')?>"></script>
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/template/style.css" />
    <script type="text/javascript">
        $(function(){
        $('table.data-table.full').dataTable( {
                "bPaginate": true,
                "aLengthMenu": [2,5, 8, 10],
                "bLengthChange": true,
                "bFilter": true,
                "bSort": true,
                "bInfo": true,
                "bAutoWidth": true,
                "sPaginationType": "full_numbers",
                "sDom": '<""f>t<"F"lp>',
                "sPaginationType": "bootstrap"
            });
        });
    </script>
    <title>Tienda online</title>

    <!-- Bootstrap Core CSS -->
    <link href="public/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
    body {
        
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>
<script src="public/js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="public/js/bootstrap.min.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" 
                data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo base_url('laptops/listar');?>">TIENDA ONLINE</a>
              <!--  <a class="navbar-brand" href="#"><-?php foreach ($tablas as $menus) { 
                    echo $menus->mennombre;
                } ?> -->
                </a>
            </div>
            
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
                    <?php foreach ($tablas as $menus) { ?>
                        <?php if ($menus->mensubid == null ) { ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo $menus->mennombre; ?> <span class="caret"></span>
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <?php foreach ($subtablas as $submenus) { ?>
                                        <?php if ($menus->menid == $submenus->mensubid) { ?>
                                            <li>
                                                <a href="<?php echo base_url("$submenus->mencontrolador/$submenus->menaccion") ?>"><?php echo $submenus->mennombre; ?></a>
                                            </li>
                                        <?php } ?>
                                    <?php } ?>
                                </ul>
                            </li>
                        <?php } ?>
   
                    <?php } ?>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a class="navbar-brand" href="<?php echo base_url('Login/user_logout');?>">Logout</a></li>

                </ul>
                
              <!--  <a class="navbar-brand" href="#"><-?php foreach ($tablas as $menus) { 
                    echo $menus->mennombre;
                } ?> -->
                </a>
            </div>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
</head>
  
</head>
<body>
 <div class="container-fluid">
  <div class="row-fluid">
   <div class="col-md-6">
    <h4 class="text-center">CRUD de usuario</h4>
    <hr>
    <span class="error"><?php if(isset($mensaje)){ echo $mensaje; }  ?></span>
    <form method="post" action="<?php echo base_url() ?>usuarioController/guardar">
     <input type="hidden" name="usuid"
     value ="<?php if(isset($usuario)){ echo ($usuario[0]->{'usuid'}); }else{echo "0"; } ?>">

     
     <div class="form-group">
     <label for = "name">perfil: </label>
     <select name="txtIdperf" class="form-control">
              <?php foreach ($selPerfil as $value) { ?>
                <option value="<?php echo $value->perid?>"> <?php echo $value->pernombre; ?></option>
              <?php } ?>
              </select>
   </div>



   <div class="form-group">
  <label for = "name">Dni: </label>
  <input type="number" name="usudni" placeholder="77293117" size="8"
  maxlength="8" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
  value="<?php if(isset($usuario)){  echo($usuario[0]->{'usudni'}); }?>"
  class="form-control" required>
</div>





     <div class="form-group">
      <label for = "name">Email: </label>
      <input type="email" name="usuemail" placeholder="asas@gmail.com" size="30"
      value="<?php if(isset($usuario)){  echo($usuario[0]->{'usuemail'}); }?>"
      class="form-control" required>
     </div>

     <div class="form-group">
      <label for ="name">Contrasenia: </label>
      <input type="text" name="usucontrasenia" placeholder="*********" size="50"
      value="<?php if(isset($usuario)){ echo($usuario[0]->{'usucontrasenia'}); }?>"
      class="form-control" required>
     </div>

     <div class="form-group">
      <label for = "name">Nombres: </label>
      <input type="text" name="usunombres" placeholder="javier" size="30"
      value="<?php if(isset($usuario)){  echo($usuario[0]->{'usunombres'}); }?>"
      class="form-control" required >
     </div>
     <div class="form-group">
      <label for = "name">Apellidos: </label>
      <input type="text" name="usuapellidos" placeholder="huamani herrera" size="50"
      value="<?php if(isset($usuario)){  echo($usuario[0]->{'usuapellidos'}); }?>"
      class="form-control" required>
     </div>

     <div class="form-group">
      <label for = "name">Celular: </label>
      <input type="number" name="usucelular" placeholder="996298178" size="9"  pattern="[0-9]{9}"
      maxlength="9" oninput="if(this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);"
      required
      value="<?php if(isset($usuario)){  echo($usuario[0]->{'usucelular'}); }?>"
      class="form-control">
     </div>

     <div class="invisible">
         <input class="form-control" placeholder="1" name="usuestado" type="number" Value="1" >
     </div>




     <div class="form-group">
      <input type="submit" value="<?php if(isset($usuario)){echo "Editar";}else{ echo  "Guardar"; } ?>" class="btn btn-success"/>
      <a class="btn btn-danger" href="javascript:history.go(-1);">Atras </a>
     

    </form>
   </div>
  </div>
 </div>
</body>
</html>
