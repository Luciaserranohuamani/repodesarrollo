<!-- LUCIA-->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="<?php echo base_url('public/css/bootstrap.css')?>" rel="stylesheet">
    <!--<link rel="stylesheet" href="public/css/bootstrap.min.css">-->

    <script src="<?php echo base_url('public/js/jquery.min.js')?>"></script>
    <script src="<?php echo base_url('public/js/bootstrap.js')?>"></script>

    <script src="<?php echo base_url('public/js/jquery.dataTables.min.js')?>"></script>
    <script src="<?php echo base_url('public/js/jquery.dataTables.bootstrap.js')?>"></script>
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/template/style.css" />
    <script type="text/javascript">
        $(function(){
        $('table.data-table.full').dataTable( {
                "bPaginate": true,
                "aLengthMenu": [2,5, 8, 10],
                "bLengthChange": true,
                "bFilter": true,
                "bSort": true,
                "bInfo": true,
                "bAutoWidth": true,
                "sPaginationType": "full_numbers",
                "sDom": '<""f>t<"F"lp>',
                "sPaginationType": "bootstrap"
            });
        });
    </script>
    <title>Tienda online</title>

    <!-- Bootstrap Core CSS -->
    <link href="public/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
    body {
        
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    
    </style>
<script src="public/js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="public/js/bootstrap.min.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" 
                data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo base_url('laptops/listar');?>">TIENDA ONLINE</a>
              <!--  <a class="navbar-brand" href="#"><-?php foreach ($tablas as $menus) { 
                    echo $menus->mennombre;
                } ?> -->
                </a>
            </div>
            
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                
                <ul class="nav navbar-nav navbar-right">
                    <li><a class="navbar-brand" href="<?php echo base_url('Login/user_logout');?>">Login/Logout</a></li>

                </ul>
                
              <!--  <a class="navbar-brand" href="#"><-?php foreach ($tablas as $menus) { 
                    echo $menus->mennombre;
                } ?> -->
                </a>
            </div>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
</head>
  <script>
    $(document).ready(function (e) {
    $("#form-login").on('submit',(function(e) {
        e.preventDefault();
        $("#message").empty();
        $('#loading').show();
    $.ajax({
        url: "<?php echo base_url('login/validar')?>",
        type: "POST",
        data: new FormData(this),
        contentType:false,
        cache: false,
        processData:false,
        success: function(data)
        {
            if(data.length !== 0){
                $('#loading').hide();
                $("#message").html(data);
            }
            else{
                window.location.href="<?php echo base_url('laptops/listar')?>";
                throw new Error('go');
            }
        }
    });
    }));
  });
</script>
</head>
<body>
<h3 class=".text-primary">
  
</h3>
<form id="form-login" action="" method="post">
  <div class="container">
    <div  class ="row">
      <div class = "col-md-3 col-md-offset-4"><br><br><br>
        <div class="panel panel-default" >
          <div class="panel-body">
            <h2>LOGIN</h2>
            
            <div class="form-group">
              <label for="exampleInputEmail1">CORREO ELECTRONICO</label>
              <input type="text" name="txtCorreo" class="form-control" id="exampleInputEmail1" placeholder="example@seguridad.com">
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">CONTRASENIA</label>
              <input type="password" name="txtContrasenia" class="form-control" id="exampleInputEmail1" placeholder="*********">
            </div>
            <button  type="submit" class="btn btn-success">INGRESAR</button>
            <center><b>No estas registrado ?</b> <br></b><a href="<?php echo base_url('Login'); ?>">Registrate aqui</a></center>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</form>
</body>
</html>



