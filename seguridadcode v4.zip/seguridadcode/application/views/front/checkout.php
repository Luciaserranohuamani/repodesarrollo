
<!-- Frank-->

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="<?php echo base_url('public/css/bootstrap.css')?>" rel="stylesheet">
    <!--<link rel="stylesheet" href="public/css/bootstrap.min.css">-->

    <script src="<?php echo base_url('public/js/jquery.min.js')?>"></script>
    <script src="<?php echo base_url('public/js/bootstrap.js')?>"></script>

    <script src="<?php echo base_url('public/js/jquery.dataTables.min.js')?>"></script>
    <script src="<?php echo base_url('public/js/jquery.dataTables.bootstrap.js')?>"></script>
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/template/style.css" />
    <script type="text/javascript">
        $(function(){
        $('table.data-table.full').dataTable( {
                "bPaginate": true,
                "aLengthMenu": [2,5, 8, 10],
                "bLengthChange": true,
                "bFilter": true,
                "bSort": true,
                "bInfo": true,
                "bAutoWidth": true,
                "sPaginationType": "full_numbers",
                "sDom": '<""f>t<"F"lp>',
                "sPaginationType": "bootstrap"
            });
        });
    </script>
    <title>Tienda online</title>

    <!-- Bootstrap Core CSS -->
    <link href="public/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
    body {
        
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>
<script src="public/js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="public/js/bootstrap.min.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" 
                data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo base_url('laptops/listar');?>">TIENDA ONLINE</a>
              <!--  <a class="navbar-brand" href="#"><-?php foreach ($tablas as $menus) { 
                    echo $menus->mennombre;
                } ?> -->
                </a>
            </div>
            
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <?php foreach ($tablas as $menus) { ?>
                        <?php if ($menus->mensubid == null ) { ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo $menus->mennombre; ?> <span class="caret"></span>
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <?php foreach ($subtablas as $submenus) { ?>
                                        <?php if ($menus->menid == $submenus->mensubid) { ?>
                                            <li>
                                                <a href="<?php echo base_url("$submenus->mencontrolador/$submenus->menaccion") ?>"><?php echo $submenus->mennombre; ?></a>
                                            </li>
                                        <?php } ?>
                                    <?php } ?>
                                </ul>
                            </li>
                        <?php } ?>
   
                    <?php } ?>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a class="navbar-brand" href="<?php echo base_url('Login/user_logout');?>">Login/Logout</a></li>

                </ul>
                
              <!--  <a class="navbar-brand" href="#"><-?php foreach ($tablas as $menus) { 
                    echo $menus->mennombre;
                } ?> -->
                </a>
            </div>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
</head>
<body>
    <div id="container">

<div id="menu">
    <ul>
        
    <?php if($total_items=$this->cart->total_items()):?> <li><?=anchor('laptops/cart','<span class="glyphicon glyphicon-shopping-cart"></span>-'.$total_items);?></li> <?php endif; ?>
      
    </ul>
</div><!-- End Menu -->
<div id="content">
<?php if($this->cart->contents()){ // el formulario se puede ver solo si existe el carrito?>

<?php if(validation_errors()): ?>
   
    <div id="error"><?=validation_errors();?></div>
   
<?php endif ?>

<?php $attributes = array('id' => 'form_checkout'); ?>
<div id="checkout">
<?=form_open('laptops/checkout', $attributes);
        /*<?php echo $this->session->userdata('usunombres'); ?>*/
     /*  $name = array('name'=>'name', 'id'=>'name','placeholder'=>'Nombre y apellidos','value'=>set_value($this->session->userdata('usunombres')), 'size'=> '35',);
       $phone = array('name'=>'phone', 'id'=>'phone','placeholder'=>'Teléfono o celular','value'=>set_value('phone'), 'size'=> '35',);
       $address = array('name'=>'address','id'=>'address','placeholder'=>'Ciudad y dirección','value'=>set_value('address'), 'size'=> '48',);
       $email = array('name'=>'email', 'id'=>'email','placeholder'=>'Correo electronico', 'value'=>set_value('email'), 'size'=> '48',); 
 ?> 
      <!--<div><?=form_label('Nombre');?></div>-->                
      <div><?=form_input($name);?></div>
      <div><?=form_label('Celular');?></div> 
      <div><?=form_input($phone);?></div> 
      <div><?=form_label('Ciudad y direccción');?></div> 
      <div><?=form_input($address);?></div> 
      <div><?=form_label('Email');?></div>   
      <div><?=form_input($email);?></div> 
     */?>
<div id='button'>
    <?=form_submit('submit', 'Enviar');?> 
</div> 
<?=form_close();?> 

</div>  
<?php }

else{
      redirect('laptops/listar');
}
?> 
<div id="footer">

<p>Copyright &copy; 2019 Tienda virtual con CodeIgniter</p>
</div><!-- End Footer -->
</div><!-- End Container -->
</body>
</html>
<!--<body>
    <h1 align="center">Registros de la Bd con Codeigniter</h1>
<h3 align="center">
<?php  foreach($results as $result) { 
               
      echo $result->marca." ";
      echo $result->procesador." ";
     echo $result->disco_duro."<br>";
    
}
 ?>   
 </h3>
</body>
</html>-->