<!-- LUCIA-->
<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="<?php echo base_url('public/css/bootstrap.css')?>" rel="stylesheet">
    <!--<link rel="stylesheet" href="public/css/bootstrap.min.css">-->

    <script src="<?php echo base_url('public/js/jquery.min.js')?>"></script>
    <script src="<?php echo base_url('public/js/bootstrap.js')?>"></script>

    <script src="<?php echo base_url('public/js/jquery.dataTables.min.js')?>"></script>
    <script src="<?php echo base_url('public/js/jquery.dataTables.bootstrap.js')?>"></script>
    <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/template/style.css" />
    <script type="text/javascript">
        $(function(){
        $('table.data-table.full').dataTable( {
                "bPaginate": true,
                "aLengthMenu": [2,5, 8, 10],
                "bLengthChange": true,
                "bFilter": true,
                "bSort": true,
                "bInfo": true,
                "bAutoWidth": true,
                "sPaginationType": "full_numbers",
                "sDom": '<""f>t<"F"lp>',
                "sPaginationType": "bootstrap"
            });
        });
    </script>
    <title>Tienda online</title>

    <!-- Bootstrap Core CSS -->
    <link href="public/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
    body {
        
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    
    </style>
<script src="public/js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="public/js/bootstrap.min.js"></script>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" 
                data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo base_url('laptops/listar');?>">TIENDA ONLINE</a>
              <!--  <a class="navbar-brand" href="#"><-?php foreach ($tablas as $menus) { 
                    echo $menus->mennombre;
                } ?> -->
                </a>
            </div>
            
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                
                <ul class="nav navbar-nav navbar-right">
                    <li><a class="navbar-brand" href="<?php echo base_url('Login/user_logout');?>">Login/Logout</a></li>

                </ul>
                
              <!--  <a class="navbar-brand" href="#"><-?php foreach ($tablas as $menus) { 
                    echo $menus->mennombre;
                } ?> -->
                </a>
            </div>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
  </head>
  <body>

<span style="background-color:red;">
  <div class="container"><!-- container class is used to centered  the body of the browser with some decent width-->
      <div class="row"><!-- row class is used for grid system in Bootstrap-->
          <div class="col-md-4 col-md-offset-4"><!--col-md-4 is used to create the no of colums in the grid also use for medimum and large devices-->
              <div class="login-panel panel panel-success">
                  <div class="panel-heading">
                      <h3 class="panel-title">Registration</h3>
                  </div>
                  <div class="panel-body">

                  <?php
                  $error_msg=$this->session->flashdata('error_msg');
                  if($error_msg){
                    echo $error_msg;
                  }
                   ?>

                      <form role="form" method="post" action="<?php echo base_url('Login/register_user'); ?>">
                          <fieldset>
                              <div class="invisible">
                                  <input class="form-control" placeholder="1" name="perid" type="number" Value="2" >
                              </div>

                              <div class="form-group">
                                  <input class="form-control" placeholder="E-mail" name="usuemail" type="email" autofocus>
                              </div>

                              <div class="form-group">
                                  <input class="form-control" placeholder="Password" name="usucontrasenia" type="password" autofocus>
                              </div>
                              <div class="form-group">
                                  <input class="form-control" placeholder="Nombres" name="usunombres" type="text" autofocus>
                              </div>
                              
                              <div class="form-group">
                                  <input class="form-control" placeholder="Apellidos" name="usuapellidos" type="text" autofocus>
                              </div>
                              <div class="form-group">
                                  <input class="form-control" placeholder="Dni" name="usudni" type="text" autofocus>
                              </div>
                              <div class="form-group">
                                  <input class="form-control" placeholder="Celular" name="usucelular" type="number" value="">
                              </div>
                              <div class="invisible">
                                  <input class="form-control" placeholder="1" name="usuestado" type="number" Value="1" >
                              </div>

                              

                              <input class="btn btn-lg btn-success btn-block" type="submit" value="Registrar" name="registrar" >

                          </fieldset>
                      </form>
                      <center><b>Ya estas registrado ?</b> <br></b><a href="<?php echo base_url('Login/login_view'); ?>">Ingresa Aqui</a></center><!--for centered text-->
                  </div>
              </div>
          </div>
      </div>
  </div>





</span>




  </body>
</html>
