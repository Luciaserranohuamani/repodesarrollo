<!-- Frank -->
<?php

class Laptops extends CI_controller
{
    
    function __construct() {
       
        parent::__Construct();
        $this ->load->model('Products_Model');
        $this ->load->model('Model_Menu');
        $this->load->library(array('pagination', 'cart', 'form_validation','email', 'table'));
        $this->load->helper('text');
    
        }
    
    public function listar(){
        $peridmenu  =  $this->session->userdata('perid');
        $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
        $data['subtablas']=$this->Model_Menu->listarsubmenus();
        $pagination = 8;
        $config['base_url'] = base_url().'laptops/listar';
        $config['total_rows'] = $this->db->get('productos')->num_rows();
        $config['per_page'] = $pagination;
        $config['num_links'] = 20;
        $config['full_tag_open'] = "<ul class='pagination'>";
        $config['full_tag_close'] ="</ul>";
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = "<li class='disabled'><li class='active'><a href='#'>";
        $config['cur_tag_close'] = "<span class='sr-only'></span></a></li>";
        $config['next_tag_open'] = "<li>";
        $config['next_tagl_close'] = "</li>";
        $config['prev_tag_open'] = "<li>";
        $config['prev_tagl_close'] = "</li>";
        $config['first_tag_open'] = "<li>";
        $config['first_tagl_close'] = "</li>";
        $config['last_tag_open'] = "<li>";
        $config['last_tagl_close'] = "</li>";
        $config['attributes'] = array('class' => 'page-link');
        $this->pagination->initialize($config);
        $data['contenido'] = "laptops/listar";
        $data['title'] = 'Computadores Portatiles';
        $data['results'] = $this->Products_Model->get_products($pagination, $this->uri->segment(3));
        $this->load->view('products_view',$data);

        
    }
    public function add() {

        $segment = $this -> input -> post('segment');
        $url = base_url() . 'laptops/listar/' . $segment;
    
        $id = $this -> input -> post('id');
        $product = $this -> Products_Model -> get_product($id);
        $option = $this -> input -> post($product -> opcion);
    
        if ($product -> opcion) {// si el producto tiene opciones las colocamos en un arreglo
    
            foreach ($product->valores as $key => $values) {
    
                $value[] = $values;
    
            }
            $id_option = $id . $value[$option];
            // se crea una variable como identificador único
            $selected = $value[$option];
            // la opción seleccionada está en la posición $option
        }
    
        $row = '';
    
        if ($cart = $this -> cart -> contents()) {// verificamos si el carrito existe
    
            foreach ($cart as $item) {//foreach contenedor
    
                if ($item['id'] === $id && !$product -> valores) {
    
                    $row = $item['rowid'] . "-" . ($item['qty'] + 1);
                    break;
                    // si se cumple la condición el foreach dejará de ejecutarse
                }
    
                if ($this -> cart -> has_options($item['rowid'])) {
    
                    foreach ($this->cart->product_options($item['rowid']) as $key => $options) {// foreach interno
    
                        $cart_option = $item['id'] . $options;
    
                        if ($cart_option === $id_option) {
    
                            $row = $item['rowid'] . "-" . ($item['qty'] + 1);
                            break;
                        }
                    } // fin del foreach interno
    
                } // fin del if que evalua si los productos insertados en el carrtito tienen opciones
    
            }// fin del foreach contenedor
    
        }// fin del if que evalua si el carrito existe
    
        /* la variable $row contiene el rowid y el qty de cada producto concatenados; si esta
         * variable no está vacia significa que se debe actualizar el producto */
    
        if ($row !== '') {
    
            $this -> update($row, $url);
    
        } else {
            $insert = array('id' => $id, 'qty' => 1, 'price' => $product -> precio, 'name' => convert_accented_characters($product -> marca) // para quitar los acentos
            );
    
            if ($selected !== Null) {
    
                $insert['options'] = array($product -> opcion => $selected);
    
            }
    
            $this -> cart -> insert($insert);
            redirect($url);
            // si en Windows da algún problema remplazarlo por: redirect($url, 'refresh');
        }
    
    }/// fin de la método  add
    
    function update($row, $url) {
    
        $row = explode('-', $row);
        $this -> cart -> update(array('rowid' => $row[0], 'qty' => $row[1]));
    
        redirect($url);
    
    }
    
    function update_cart($row) {
    
        $row = explode('-', $row);
        $this -> cart -> update(array('rowid' => $row[0], 'qty' => $row[1]));
    
        redirect('laptops/cart');
    
    }
    
    function remove($rowid) {
    
        $this -> cart -> update(array('rowid' => $rowid, 'qty' => 0));
    
        redirect('laptops/cart');
    
    }
    
    function delete() {
        $message = 'El carrito se ha eliminado satisfactoriamente<br/>';
        $this -> cart -> destroy();
        $this -> cart($message);
    
    }
    
    function cart($message = NULL) {
        $peridmenu  =  $this->session->userdata('perid');
        $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
        $data['subtablas']=$this->Model_Menu->listarsubmenus();
        $data['message'] = $message;
        $data['title'] = 'Carrito de Compras';
        $data['contenido'] = "laptops/cart";
        $this -> load -> view('front/cart', $data);
   
    
    }
    function checkout(){
        $peridmenu  =  $this->session->userdata('perid');
        $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
        $data['subtablas']=$this->Model_Menu->listarsubmenus();
        $data['contenido'] = "laptops/checkout";


      $data['title'] = 'Solicitar Pedido'; 
      
       /*$this->form_validation->set_rules('name', 'Nombre');
       $this->form_validation->set_rules('phone', 'Celular', 'required|numeric');
       $this->form_validation->set_rules('address', 'Ciudad y dirección', 'required');
       $this->form_validation->set_rules('email', 'Email', 'required|valid_email');   
      
       $this->form_validation->set_message('required', 'el campo %s es requerido');
       $this->form_validation->set_message('valid_email', 'El email no es válido');
         
           $this -> form_validation -> set_error_delimiters('<ul><li>', '</li></ul>');
       */
       
    if ($this->form_validation->run() == true)
        {
            $this->load->view('front/checkout', $data);  

           
            }else{
                       
            $name =  $this->session->userdata('usunombres').' '.$this->session->userdata('usuapellidos');
            $mobil = $this->session->userdata('usucelular');
            $email = $this->session->userdata('usuemail');
                       
if($cart=$this->cart->contents()){
    
$this->table->set_heading('Portatil&nbsp&nbsp', '&nbsp&nbspDetalle&nbsp','Cantidad&nbsp&nbsp','Precio&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp', 'Total'); // la tabla que irá en el correo


    foreach($cart as $item){
        $selected = '';       
     if ($this->cart->has_options($item['rowid'])) {
            foreach ($this->cart->product_options($item['rowid']) as $option => $value) {
                                $selected = '&nbsp&nbsp'.$option .' <em>' . $value.'&nbsp&nbsp&nbsp&nbsp&nbsp' ;
                          }
                      }
              
              $price = ($item['price']*$item['qty']); 
               $this->table->add_row($item['name'], $selected, $item['qty'], $price);
                                   
             } // fin del foreach
         
 $this->table->add_row('<br/>Total', '<br/>', '<br/>', '<br/>', '<br/>'.$this->cart->format_number($this->cart->total()));
             
    $message = 'Señor(a): '.$name.'<br/>'.'Celular: '.$mobil.'<br/>'.'Email: '.$email.'<br/>'.'Detalles del pedido';                                     
    
    $pedido = $message.'<br/>'.$this->table->generate();  // concatenamos el mensaje con la tabla que contiene el pedido
           
   /* $config = array('protocol'=>'smtp', 
                    'smtp_host'=>'smtp.gmail.com', 
                    'smtp_user'=>'mi-correo@gmail.com', // colocamos nuestra propia cuenta de Gmail
                    'smtp_pass'=>'mi-password', // contraseña de la cuenta Gmail                   
                    'smtp_port'=>'465', 
                    'smtp_timeout'=>'6', 
                    'mailtype'=>'html',                   
                    );
                   
   $this->email->initialize($config);
   */
            // Datos para enviar el correo
            $this->email->from('admin-tienda@gmail.com', 'Tienda virtual');
            $this->email->to($email);
            $this->email->subject('Pedido de Computador(es) Portatil(es)');               
            $this->email->message($pedido); 
            $this->email->send(); // envia el correo
           
            $data['title']='Detalles del Pedido';
            $data['pedido']=$pedido;
                   //  echo $this->email->print_debugger(); exit;                           
             $this->load->view('front/success', $data);

             
            } 
        } // fin del else
    } // fin del método

    

}