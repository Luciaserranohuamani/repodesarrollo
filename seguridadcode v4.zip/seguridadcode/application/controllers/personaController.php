<!-- JOSEPH-->
<?php



class personaController extends CI_Controller
{

function __construct()
{
 parent::__construct();
 $this->load->model('modelPersona');
 $this ->load->model('Model_Menu');
 $this->load->library(array('pagination', 'cart', 'form_validation','email', 'table'));
 $this->load->helper('text');
}

public function crear(){
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
 $this->load->view('persona',$data);
}
public function index(){
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
 $data["personas"] = $this->modelPersona->listado();
 $this->load->view("listado", $data);
}

public function guardar(){
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
 $parametros = array (
            "marca" => $this->input->post('marca'),
            "pantalla" => $this->input->post('pantalla'),
              "ram" => $this->input->post('ram'),
                  "procesador" => $this->input->post('procesador'),
                  "disco_duro" => $this->input->post('disco_duro'),
                 "precio" => $this->input->post('precio'),
                 "opcion" => $this->input->post('opcion'),
                   "valores" => $this->input->post('valores'),
                     "imagen" => $this->input->post('imagen')
 );
 $id = $this->input->post('id');
 $data['personas'] = "";
 if($id == 0){
  $idInsert = $this->modelPersona->guardar($parametros);
  $idInsert > 0? $data['personas'] = $this->modelPersona->listado() : $data['personas'] = "Ocurrio un Error Al Insertar";

  $this->load->view("listado", $data);
     }else{
  $idEdit = $this->modelPersona->actualizar($parametros, $id);
  $idEdit > 0? $data['personas'] = $this->modelPersona->listado() : $data['personas'] = "Ocurrio un Error Al Editar";
  $this->load->view("listado", $data);
     }
}

public function listado(){
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
 $data["personas"] = $this->modelPersona->listado();
 $this->load->view("listado", $data);
}

public function editar($id){
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
 $parametro = array (
  "id" => $id
 );
 $data["persona"] =  $this->modelPersona->editar($parametro);
 $this->load->view("persona", $data);
}

public function eliminar($id){
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
 $parametro = array (
  "id" => $id
 );
 $this->modelPersona->eliminar($parametro);
 $data["personas"] = $this->modelPersona->listado();
 $this->load->view("listado", $data);
}

}
