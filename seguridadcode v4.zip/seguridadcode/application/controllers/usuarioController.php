<!-- JOSEPH-->
<?php

/**
*
*/
class usuarioController extends CI_Controller
{

function __construct()
{
 parent::__construct();
 $this->load->model('modelUsuario');
 $this ->load->model('Model_Menu');
 $this->load->library(array('pagination', 'cart', 'form_validation','email', 'table'));
 $this->load->helper('text');

}

public function crear(){
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
  $data['selPerfil'] = $this->modelUsuario->selPerfil();
 $this->load->view('usuario',$data);
}
public function index(){
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
  $data["personas"] = $this->modelUsuario->listado();
  $data['selPerfil'] = $this->modelUsuario->selPerfil();
  $this->load->view("listado_usuario", $data);
 
}

public function guardar(){
  
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
  
 $parametros = array (
   "perid" => $this->input->post('perid'),
     "usudni" => $this->input->post('usudni'),
     "usuemail" => $this->input->post('usuemail'),
      "usucontrasenia" => $this->input->post('usucontrasenia'),
     "usunombres" => $this->input->post('usunombres'),
         "usuapellidos" => $this->input->post('usuapellidos'),
       "usucelular" => $this->input->post('usucelular'),
       "usuestado" => $this->input->post('usuestado')



 );
 $usuid = $this->input->post('usuid');
 $data['personas'] = "";
 if($usuid == 0){
  $idInsert = $this->modelUsuario->guardar($parametros);
  $idInsert > 0? $data['personas'] = $this->modelUsuario->listado() : $data['personas'] = "Ocurrio un Error Al Insertar";

  $this->load->view("listado_usuario", $data);
     }else{
  $idEdit = $this->modelUsuario->actualizar($parametros, $usuid);
  $idEdit > 0? $data['personas'] = $this->modelUsuario->listado() : $data['personas'] = "Ocurrio un Error Al Editar";
  $this->load->view("listado_usuario", $data);
     }
}

public function listado(){
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
 $data["personas"] = $this->modelUsuario->listado();
 $this->load->view("listado_usuario", $data);
}

public function editar($usuid){
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
  $data['selPerfil'] = $this->modelUsuario->selPerfil();
 $parametro = array (
  "usuid" => $usuid
 );
 $data["usuario"] =  $this->modelUsuario->editar($parametro);
 $this->load->view("usuario", $data);
}

public function eliminar($usuid){
  $peridmenu  =  $this->session->userdata('perid');
  $data['tablas']=$this->Model_Menu->listarmenus($peridmenu);
  $data['subtablas']=$this->Model_Menu->listarsubmenus();
 $parametro = array (
  "usuid" => $usuid
 );
 $this->modelUsuario->eliminar($parametro);
 $data["personas"] = $this->modelUsuario->listado();
 $this->load->view("listado_usuario", $data);
}

}
