<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller{
  /*public function index(){
    $this->load->view('login');
  }

  public function lista(){
    $this->load->view('lista');
  }*/

  function __construct(){
    parent:: __construct();
    $this->load->model('Model_Login');
  }

  public function index()
  {
    $data['contenido']="login";
    $this->load->view("register.php");
    //$this->load->view("plantilla",$data);
    
  }
  public function login_view(){

    $this->load->view("login.php");
    
    }
  public function validar(){
     $datos=$this->input->post();
     $correo=$datos["txtCorreo"];
     $contrasenia=$datos["txtContrasenia"];
    
     $datosusuario=$this->Model_Login->existeUsuario($correo,$contrasenia);
    
    foreach ($datosusuario as $value) {
      $nombres=$value->usunombres;
      $estado=$value->usuestado;
      $perfil=$value->perid;
    }
    
    if(count($datosusuario)>0 && $estado==1){

      $datoscomp=array(
        'usunombres'=>$nombres,
        'usuemail'=>$correo,
        'perid'=>$perfil, 
        'logged_in'=>TRUE
      );

      $this->session->set_userdata($datoscomp);
    }

    else{
      $messageCorrecto = "<div id='success' class=\"alert alert-danger alert-dismissible\" role=\"alert\">
                <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                <strong>Hola $correo !</strong> Error en usuario y/o contraseña.
                </div>";

      echo $messageCorrecto;
    }
  }
  public function register_user(){

    $user=array(
    'perid'=>$this->input->post('perid'),
    'usudni'=>$this->input->post('usudni'),
    'usuemail'=>$this->input->post('usuemail'),
    'usucontrasenia'=>$this->input->post('usucontrasenia'),
    'usunombres'=>md5($this->input->post('usunombres')),
    'usuapellidos'=>$this->input->post('usuapellidos'),
    'usucelular'=>$this->input->post('usucelular'),
    'usuestado'=>$this->input->post('usuestado')
      );
      print_r($user);

$email_check=$this->Model_Login->email_check($user['usuemail']);

if($email_check){
$this->Model_Login->register_user($user);
$this->session->set_flashdata('success_msg', 'Registered successfully.Now login to your account.');
redirect('Login/login_view');

}
else{

$this->session->set_flashdata('error_msg', 'Error occured,Try again.');
redirect('Login');


}


}
public function user_logout(){

  $this->session->sess_destroy();
  redirect('Login/login_view', 'refresh');
}
}
?>