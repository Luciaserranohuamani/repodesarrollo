<?php

class Laptops extends CI_controller
{
    function __construct(){
        parent:: __construct();
        $this->load->model('catalogo_model');
    }

    public function listar()
    {
        # code... enviar a plattilla la vista index
        $data['contenido'] = "laptops/listar";
        //$data['selPerfil'] = $this->Model_Usuario->selPerfil();

        $this->load->view("catalogo_view",$data);
        
    }

}