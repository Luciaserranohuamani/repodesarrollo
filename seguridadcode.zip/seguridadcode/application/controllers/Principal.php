<?php

/**
 *
 */
class Principal extends CI_Controller
{

  function __construct()
  {
    parent::__construct();
  }

  public function index(){
    //$data['contenido']='principal';
    $data['contenido']='laptops/listar';
    $this->load->view('catalogo_view',$data);
  }
  public function listar()
  {
    $data['contenido']='laptops/listar';
    $this->load->view('catalogo_view',$data);
  }
}
