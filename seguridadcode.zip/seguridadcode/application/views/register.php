<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Registration-CI Login Registration</title>

<link href="<?php echo base_url('public/css/bootstrap.css') ?>" rel="stylesheet">
<script src="<?php echo base_url('public/js/jquery.min.js')?>"></script>
<script src="<?php echo base_url('public/js/bootstrap.js')?>"></script>

  </head>
  <body>

<span style="background-color:red;">
  <div class="container"><!-- container class is used to centered  the body of the browser with some decent width-->
      <div class="row"><!-- row class is used for grid system in Bootstrap-->
          <div class="col-md-4 col-md-offset-4"><!--col-md-4 is used to create the no of colums in the grid also use for medimum and large devices-->
              <div class="login-panel panel panel-success">
                  <div class="panel-heading">
                      <h3 class="panel-title">Registration</h3>
                  </div>
                  <div class="panel-body">

                  <?php
                  $error_msg=$this->session->flashdata('error_msg');
                  if($error_msg){
                    echo $error_msg;
                  }
                   ?>

                      <form role="form" method="post" action="<?php echo base_url('Login/register_user'); ?>">
                          <fieldset>
                              <div class="invisible">
                                  <input class="form-control" placeholder="1" name="perid" type="number" Value="2" >
                              </div>

                              <div class="form-group">
                                  <input class="form-control" placeholder="E-mail" name="usuemail" type="email" autofocus>
                              </div>

                              <div class="form-group">
                                  <input class="form-control" placeholder="Password" name="usucontrasenia" type="password" autofocus>
                              </div>
                              <div class="form-group">
                                  <input class="form-control" placeholder="Nombres" name="usunombres" type="text" autofocus>
                              </div>
                              
                              <div class="form-group">
                                  <input class="form-control" placeholder="Apellidos" name="usuapellidos" type="text" autofocus>
                              </div>
                              <div class="form-group">
                                  <input class="form-control" placeholder="Dni" name="usudni" type="text" autofocus>
                              </div>
                              <div class="form-group">
                                  <input class="form-control" placeholder="Celular" name="usucelular" type="number" value="">
                              </div>
                              <div class="invisible">
                                  <input class="form-control" placeholder="1" name="usuestado" type="number" Value="1" >
                              </div>

                              

                              <input class="btn btn-lg btn-success btn-block" type="submit" value="Registrar" name="registrar" >

                          </fieldset>
                      </form>
                      <center><b>Ya estas registrado ?</b> <br></b><a href="<?php echo base_url('Login/login_view'); ?>">Ingresa Aqui</a></center><!--for centered text-->
                  </div>
              </div>
          </div>
      </div>
  </div>





</span>




  </body>
</html>
